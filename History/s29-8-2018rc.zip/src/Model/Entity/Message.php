<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Message Entity.
 */
class Message extends Entity
{
	use TimezonedTrait;

}
