<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * OwnerPrice Entity.
 */
class OwnerPrice extends Entity
{
	use TimezonedTrait;

}
