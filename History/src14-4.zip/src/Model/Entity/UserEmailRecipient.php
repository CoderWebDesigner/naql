<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * UserEmailRecipient Entity.
 */
class UserEmailRecipient extends Entity
{
	use TimezonedTrait;

}
