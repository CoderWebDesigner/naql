<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Owners Controller
 *
 * @property \App\Model\Table\OwnersTable $Owners
 * @property \Alaxos\Controller\Component\FilterComponent $Filter
 */
class OwnersController extends AppController
{

    /**
     * Helpers
     *
     * @var array
     */
    public $helpers = ['Alaxos.AlaxosHtml', 'Alaxos.AlaxosForm', 'Alaxos.Navbars'];

    /**
     * Components
     *
     * @var array
     */
    public $components = ['Alaxos.Filter'];

    /**
    * Index method
    *
    * @return void
    */
    public function index()
    {
          $this->viewBuilder()->layout('front');
        $this->paginate = [
            'contain' => ['Users']
        ];
        $this->set('owners', $this->paginate($this->Filter->getFilterQuery()));
        $this->set('_serialize', ['owners']);
        
        $users = $this->Owners->Users->find('list', ['limit' => 200]);
        $this->set(compact('users'));
    }

    /**
     * View method
     *
     * @param string|null $id Owner id.
     * @return void
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function view($id = null)
    {
          $this->viewBuilder()->layout('front');
        $owner = $this->Owners->get($id, [
            'contain' => ['Users', 'MachineOwners', 'Rates', 'Reservations']
        ]);
        $this->set('owner', $owner);
        $this->set('_serialize', ['owner']);
    }

    /**
     * Add method
     *
     * @return void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        debug($this->request->data());
        $this->viewBuilder()->layout('front');
        $owner = $this->Owners->newEntity();
        if ($this->request->is('post')) {
               ////////////////////////
               $user = $this->Owners->Users->newEntity();
               $user = $this->Owners->Users->patchEntity($user , $this->request->data);
                $this->Owners->Users->save($user);
                ////////////////////////
                $userID = $user->id ;
                $this->request->data['user_id'] = $userID ; 
            $owner = $this->Owners->patchEntity($owner, $this->request->data);
            if ($this->Owners->save($owner)) {
             
                $this->Flash->success(___('the owner has been saved'), ['plugin' => 'Alaxos']);
          //      return $this->redirect(['action' => 'view', $owner->id]);
            } else {
                $this->Flash->error(___('the owner could not be saved. Please, try again.'), ['plugin' => 'Alaxos']);
            }
        }
        $users = $this->Owners->Users->find('list', ['limit' => 200]);
        $this->set(compact('owner', 'users','user'));
        $this->set('_serialize', ['owner']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Owner id.
     * @return void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
          $this->viewBuilder()->layout('front');
        $owner = $this->Owners->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $owner = $this->Owners->patchEntity($owner, $this->request->data);
            if ($this->Owners->save($owner)) {
                $this->Flash->success(___('the owner has been saved'), ['plugin' => 'Alaxos']);
                return $this->redirect(['action' => 'view', $owner->id]);
            } else {
                $this->Flash->error(___('the owner could not be saved. Please, try again.'), ['plugin' => 'Alaxos']);
            }
        }
        $users = $this->Owners->Users->find('list', ['limit' => 200]);
        $this->set(compact('owner', 'users'));
        $this->set('_serialize', ['owner']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Owner id.
     * @return void Redirects to index.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $owner = $this->Owners->get($id);
        
        try
        {
            if ($this->Owners->delete($owner)) {
                $this->Flash->success(___('the owner has been deleted'), ['plugin' => 'Alaxos']);
            } else {
                $this->Flash->error(___('the owner could not be deleted. Please, try again.'), ['plugin' => 'Alaxos']);
            }
        }
        catch(\Exception $ex)
        {
            if($ex->getCode() == 23000)
            {
                $this->Flash->error(___('the owner could not be deleted as it is still used in the database'), ['plugin' => 'Alaxos']);
            }
            else
            {
                $this->Flash->error(sprintf(__('The owner could not be deleted: %s'), $ex->getMessage()), ['plugin' => 'Alaxos']);
            }
        }
        
        return $this->redirect(['action' => 'index']);
    }
    
    /**
     * Delete all method
     */
    public function delete_all() {
        $this->request->allowMethod('post', 'delete');
        
        if(isset($this->request->data['checked_ids']) && !empty($this->request->data['checked_ids'])){
            
            $query = $this->Owners->query();
            $query->delete()->where(['id IN' => $this->request->data['checked_ids']]);
            
            try{
                if ($statement = $query->execute()) {
                    $deleted_total = $statement->rowCount();
                    if($deleted_total == 1){
                        $this->Flash->set(___('the selected owner has been deleted.'), ['element' => 'Alaxos.success']);
                    }
                    elseif($deleted_total > 1){
                        $this->Flash->set(sprintf(__('The %s selected owners have been deleted.'), $deleted_total), ['element' => 'Alaxos.success']);
                    }
                } else {
                    $this->Flash->set(___('the selected owners could not be deleted. Please, try again.'), ['element' => 'Alaxos.error']);
                }
            }
            catch(\Exception $ex){
                $this->Flash->set(___('the selected owners could not be deleted. Please, try again.'), ['element' => 'Alaxos.error', 'params' => ['exception_message' => $ex->getMessage()]]);
            }
        } else {
            $this->Flash->set(___('there was no owner to delete'), ['element' => 'Alaxos.error']);
        }
        
        return $this->redirect(['action' => 'index']);
    }
    
    /**
     * Copy method
     *
     * @param string|null $id Owner id.
     * @return void Redirects on successful copy, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function copy($id = null)
    {
        $owner = $this->Owners->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $owner = $this->Owners->newEntity();
            $owner = $this->Owners->patchEntity($owner, $this->request->data);
            if ($this->Owners->save($owner)) {
                $this->Flash->success(___('the owner has been saved'), ['plugin' => 'Alaxos']);
                return $this->redirect(['action' => 'view', $owner->id]);
            } else {
                $this->Flash->error(___('the owner could not be saved. Please, try again.'), ['plugin' => 'Alaxos']);
            }
        }
        $users = $this->Owners->Users->find('list', ['limit' => 200]);
        
        $owner->id = $id;
        $this->set(compact('owner', 'users'));
        $this->set('_serialize', ['owner']);
    }
}
