<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Area Entity.
 */
class Area extends Entity
{
	use TimezonedTrait;

}
