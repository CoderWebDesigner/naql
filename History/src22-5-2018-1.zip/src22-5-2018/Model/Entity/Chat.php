<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Chat Entity.
 */
class Chat extends Entity
{
	use TimezonedTrait;

}
