<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * MachineDetail Entity.
 */
class MachineDetail extends Entity
{
	use TimezonedTrait;

}
