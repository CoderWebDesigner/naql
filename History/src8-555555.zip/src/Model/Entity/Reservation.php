<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Reservation Entity.
 */
class Reservation extends Entity
{
	use TimezonedTrait;

}
