<?php namespace App\Controller\Api;
 use App\Controller\Api\AppController;

/**
 * BlackLists Controller
 *
 * @property \App\Model\Table\BlackListsTable $BlackLists
 * @property \Alaxos\Controller\Component\FilterComponent $Filter
 */
class MessagesController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('RequestHandler');
          $this->loadComponent('Paginator');
                  $this->Auth->allow(['index','add','edit','view','myChat']);

    }
    
    
     public $paginate = [
        'page' => 1,
        'limit' => 1000,
        'maxLimit' => 100,
       'fields' => [],
        'sortWhitelist' => []
    ];
     
     
     
        public function myChat ($id) {

         $myChat = $this->Messages->find() 
            
         ->order(['Messages.created DESC'])
         ->contain([
             'Chats'=>function($q) {
                                    return $q
                                 
                                    ->order(['Chats.created DESC']) 
                                 ->contain([  'tooo'=>function($tooInfo){
                                     return $tooInfo 
                                             ->select(['username','photo','user_group_id']);
                                     
                                 }  ,'frommm'=>function($frommInfo){
                                     return $frommInfo 
                                             ->select(['username','photo','user_group_id']);
                                 }
                                 ]);
                                    } 
                                    
                                  
                                    ]) 
            
         
 
         ->where(['Messages.fromm'=>$id])
         ->orwhere(['Messages.too'=>$id])
     
         ->toarray();
         
        $userFrom = $myChat[0]['fromm'];
        $userTo =  $myChat[0]['too'];
        

  
        $this->set('myChat',$myChat);
        $this->set('_serialize', ['myChat']);  
    }
    
}
