<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * ScheduledEmailRecipient Entity.
 */
class ScheduledEmailRecipient extends Entity
{
	use TimezonedTrait;

}
