<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * SettingOption Entity.
 */
class SettingOption extends Entity
{
	use TimezonedTrait;

}
