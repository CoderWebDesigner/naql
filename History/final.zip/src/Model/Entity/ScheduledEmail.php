<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * ScheduledEmail Entity.
 */
class ScheduledEmail extends Entity
{
	use TimezonedTrait;

}
