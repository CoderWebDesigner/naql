<?php namespace App\Controller\Api;
 use App\Controller\Api\AppController;

/**
 * BlackLists Controller
 *
 * @property \App\Model\Table\BlackListsTable $BlackLists
 * @property \Alaxos\Controller\Component\FilterComponent $Filter
 */
class ReservationsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('RequestHandler');
        $this->loadComponent('Paginator');
        $this->Auth->allow(['index','add','edit','view','completedResForUser','resStatusForUserAowner','orders']);

    }
    
    
     public $paginate = [
        'page' => 1,
        'limit' => 1000,
        'maxLimit' => 100,
       'fields' => [],
        'sortWhitelist' => []
    ];
     
      public function add()
    {
        $reservation = $this->Reservations->newEntity();
        if ($this->request->is('post')) {
            $reservation = $this->Reservations->patchEntity($reservation, $this->request->data);
            if ($this->Reservations->save($reservation)) {
                $success = true ;
             } else {
                   $success = false ;
             }
        }
 
        $this->set(compact('success','reservation'));
        $this->set('_serialize', ['success','reservation']);
    }
//////////////////////////////////////////////////////
    function resStatusForUserAowner(){   //after owner accpet order
$userID = $this->request->data['userID'] ; 
$ownerID = $this->request->data['ownerID'] ; 
$status = $this->request->data['status'];
        $data = $this->Reservations->find('all')
                ->where(['Reservations.user_id'=>$userID , 'Reservations.status'=>$status])
                ->orwhere(['Reservations.owner_id'=>$ownerID , 'Reservations.status'=>$status])
                ->toArray();
        $success = true ; 
                $this->set(compact('success','data'));
        $this->set('_serialize', ['success','data']);
    }

    
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
    function orders($ownerID){   // order before aproved
         $chkMachines = $this->Reservations->MachineDetails->MachineOwners->find('all')
                 ->where(['MachineOwners.owner_id'=>$ownerID])->toArray();
        
         foreach($chkMachines as $chkMachiness):
             $machineDetails[] =  $chkMachiness['machine_detail_id'] ; 
         endforeach;
        // chk orders by 
 
$status = 'pending';
        $data = $this->Reservations->find('all')
                ->where(['Reservations.machine_detail_id IN'=>$machineDetails , 'Reservations.status'=>$status])
                ->toArray();
        $success = true ; 
                $this->set(compact('success','data','chkMachines','machineDetails'));
        $this->set('_serialize', ['success','data']);
    }

    
//////////////////////////////////////////////////////
    // order status (pending , waiting , approved , canceled , completed )
    

}
