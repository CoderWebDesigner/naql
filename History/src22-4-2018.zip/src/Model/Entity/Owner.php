<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Owner Entity.
 */
class Owner extends Entity
{
	use TimezonedTrait;

}
