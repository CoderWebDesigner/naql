<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Setting Entity.
 */
class Setting extends Entity
{
	use TimezonedTrait;

}
