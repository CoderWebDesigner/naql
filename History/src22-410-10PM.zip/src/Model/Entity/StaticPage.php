<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * StaticPage Entity.
 */
class StaticPage extends Entity
{
	use TimezonedTrait;

}
