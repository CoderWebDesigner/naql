<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * UserEmail Entity.
 */
class UserEmail extends Entity
{
	use TimezonedTrait;

}
