<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * UserEmailTemplate Entity.
 */
class UserEmailTemplate extends Entity
{
	use TimezonedTrait;

}
