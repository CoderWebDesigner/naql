<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * UserActivity Entity.
 */
class UserActivity extends Entity
{
	use TimezonedTrait;

}
