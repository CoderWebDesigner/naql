<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * UserDetail Entity.
 */
class UserDetail extends Entity
{
	use TimezonedTrait;

}
