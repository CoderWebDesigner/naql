<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Rate Entity.
 */
class Rate extends Entity
{
	use TimezonedTrait;

}
