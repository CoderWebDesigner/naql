<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * UserSetting Entity.
 */
class UserSetting extends Entity
{
	use TimezonedTrait;

}
