<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * MachineOwner Entity.
 */
class MachineOwner extends Entity
{
	use TimezonedTrait;

}
