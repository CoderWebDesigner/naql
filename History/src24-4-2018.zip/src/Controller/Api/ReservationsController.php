<?php namespace App\Controller\Api;
 use App\Controller\Api\AppController;

/**
 * BlackLists Controller
 *
 * @property \App\Model\Table\BlackListsTable $BlackLists
 * @property \Alaxos\Controller\Component\FilterComponent $Filter
 */
class ReservationsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('RequestHandler');
        $this->loadComponent('Paginator');
        $this->Auth->allow(['index','add','edit','view','completedResForUser','history','orders']);

    }
    
    
     public $paginate = [
        'page' => 1,
        'limit' => 1000,
        'maxLimit' => 100,
       'fields' => [],
        'sortWhitelist' => []
    ];
     
      public function add()
    {
        $reservation = $this->Reservations->newEntity();
        if ($this->request->is('post')) {
            $reservation = $this->Reservations->patchEntity($reservation, $this->request->data);
            if ($this->Reservations->save($reservation)) {
                  //send ownersID 
              $notificationOwner =  $this->sendOwnerId() ; 
              if($notificationOwner ==null){$success['owner']= false;$notificationOwner = 0 ;}else{$success['owner']= true;}
                // end send ownersID 
                $success['res'] = true ;
             } else {
                   $success['res'] = false ;
                   $success['owner']= false;
             }
        }
        $this->set(compact('success','reservation','allOwners','notificationOwner'));
        $this->set('_serialize', ['success','reservation','notificationOwner']);
    }
    
    
       function sendOwnerId(){
      $machineId = $this->request->data['machine_id'] ; 
                $machineDetailId = $this->request->data['machine_detail_id'] ;
                $allOwners = $this->Reservations->MachineDetails->MachineOwners->find('all')
                        ->where(['MachineOwners.machine_id' => $machineId,'MachineOwners.machine_detail_id' => $machineDetailId])->toArray();
              foreach($allOwners as $allOwnerss):
                   $notificationOwner[] = $allOwnerss['owner_id'];
              endforeach;
              return $notificationOwner ; 
}
    
    
//////////////////////////////////////////////////////
    function history($page){   //after owner accpet order
$userID = $this->request->data['userID'] ; 
$ownerID = $this->request->data['ownerID'] ; 
$status = $this->request->data['status'];
        $data = $this->Reservations->find('all');
                $data->where(['Reservations.user_id'=>$userID , 'Reservations.status'=>$status])
                ->orwhere(['Reservations.owner_id'=>$ownerID , 'Reservations.status'=>$status])
                ->toArray();
        
        
         $this->paginate = [
            'page' => $page,
            'limit' => 10,
            'maxLimit' => 100,
            'fields' => []
              ]; 
   	   $this->paginate($data);
           
        $success = true ; 
                $this->set(compact('success','data'));
        $this->set('_serialize', ['success','data']);
    }

    
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
 function machineOwner($ownerID) {
     $chkMachines = $this->Reservations->MachineDetails->MachineOwners->find('all')
                 ->where(['MachineOwners.owner_id'=>$ownerID])->toArray();
        
         foreach($chkMachines as $chkMachiness):
             $machineDetails[] =  $chkMachiness['machine_detail_id'] ; 
          
         endforeach;
         
         return $machineDetails ;
 }
//////////////////////////////////////////////////////
    function orders($ownerID){   // order before aproved
        $this->request->data['ownerID'] = $ownerID ; 
         
       $machineDetails = $this->machineOwner($ownerID);
    
        // chk orders by 
 
$status = 'pending';
        $data = $this->Reservations->find('all')
                ->where(['Reservations.machine_detail_id IN'=>$machineDetails  ,  'Reservations.status'=>$status])
                ->contain(['OwnerPrices' =>function($chkPrice){   //ownerprices to remove (pricing form post by owner)
                     return $chkPrice 
                               ->where(['OwnerPrices.owner_id'=>$this->request->data['ownerID']])
                             ->select(['owner_id','reservation_id','price'])
                             ; 
                }
                    ,'ReservationTypes' =>function($qq){
                        return $qq 
                                ->select(['name','name_en']);
                    }
                    ,'Users'=>function($elhay){
              return $elhay 
              ->select(['username','photo'])
                ;
                }])
                ->order(['Reservations.id DESC'])
                ->toArray();
        $success = true ; 
                $this->set(compact('success','data','chkMachines','machineDetails'));
        $this->set('_serialize', ['success','data','machineDetails']);
    }

    
//////////////////////////////////////////////////////

    
//////////////////////////////////////////////////////
    // order status (pending  , approved , canceled , completed )
    
    public function edit($id = null)
    {
        $reservation = $this->Reservations->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $reservation = $this->Reservations->patchEntity($reservation, $this->request->data);
            if ($this->Reservations->save($reservation)) {
                $success = true ; 
            } else {
               $success = false ; 
            }
        }
 
        $this->set(compact('reservation', 'success'));
        $this->set('_serialize', ['success','reservation']);
    }

}
