<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * UserGroupPermission Entity.
 */
class UserGroupPermission extends Entity
{
	use TimezonedTrait;

}
