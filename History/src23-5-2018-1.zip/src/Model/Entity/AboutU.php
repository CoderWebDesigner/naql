<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * AboutU Entity.
 */
class AboutU extends Entity
{
	use TimezonedTrait;

}
