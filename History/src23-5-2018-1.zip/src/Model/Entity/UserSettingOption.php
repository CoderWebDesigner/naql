<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * UserSettingOption Entity.
 */
class UserSettingOption extends Entity
{
	use TimezonedTrait;

}
